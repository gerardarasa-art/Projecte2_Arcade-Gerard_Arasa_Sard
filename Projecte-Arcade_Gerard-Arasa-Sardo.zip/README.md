# Projecte! Màquina Àrcade

# Aquesta aplicaciò el que hi fa és un Menu on hi pots jugar a dos tipus de jocs: 
# 1. Pedra, paper o tisora
# 2. Endivina el numero

# El pedra paper o tisora, jugarás contra la màquina, hi ha dos modes de dificultat, o el de 3 rondes
# o el de 5 rondes, el primer que guanyi 3/5 rondes guanyará. Després tenim el Endivina el numero,
# que consisteix en que te demana un número entre el 1 i el 100, i quan dius un número et dira
# si estas molt alt o molt baix, si dius justament el numero escollit haurás guanyat.


# El seu funcionament es poc complexe, ja que quan inicies el programa et sortirà un menú on et 
# sortirà 3 opcions, jugar a pedra paper o tisora, jugar a endevinar el número o sortir.

# Al de pedra paper tisora, a la terminal et demanara que escriguis el tipus de dificultat 
# dessitgada, o guanyar 3 o 5 rondes, seguidamen et demanara el tipus de mà dessitgada, com per 
# exemple tisora, si has guanyat al robot, t'ho dirà i repetira fins arribar a les 3/5 victòries.

# Al de endevinar el numero, quan selecciones el mode, te demanarà que possis un número entre
# 1 i 100, quan el possis, et dirà si estas molt alt o molt baix, si l'has encertat t'ho dirà
# i hauràs finalitzat el joc, en el cas que no te informarà que per exemple estas molt alt
# i hauràs de posar un altre numero repetitivament fins guanyar, en acabar et felicitarà i te dirà
# quants intents has fet.
